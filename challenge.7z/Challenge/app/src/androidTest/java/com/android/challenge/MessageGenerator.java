package com.android.challenge;

import com.android.challenge.provider.Message;

import java.util.Arrays;
import java.util.List;

public class MessageGenerator {

    public List<Message> getMockMessages(){

        List<Message> messages = Arrays.asList(
                new Message("The Secret of Successful android"),
                new Message("Warning: These 9 Mistakes Will Destroy Your android"),
                new Message("3 Ways You Can Reinvent android Without Looking Like An Amateur"));
        return messages;

    }

    public List<Message> getMockMessage(){

        List<Message> messages = Arrays.asList(
                new Message("The Secret of Successful android"));
        return messages;

    }

}
