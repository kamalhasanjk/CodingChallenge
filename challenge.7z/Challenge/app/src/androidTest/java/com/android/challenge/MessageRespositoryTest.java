package com.android.challenge;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.android.challenge.activity.ICallback;
import com.android.challenge.provider.Message;
import com.android.challenge.provider.MessagesRepository;

import junit.framework.Assert;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class MessageRespositoryTest {
    @Test
    public void useAppContext() {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        assertEquals("com.android.challenge", appContext.getPackageName());
    }

    @Test
    public void testInsertMessages(){
        Context appContext = InstrumentationRegistry.getTargetContext();
        List<Message> messages =  new MessageGenerator().getMockMessages();
        MessagesRepository.getInstance(appContext).insertMessages(messages);
        MessagesRepository.getInstance(appContext).getMessages(new ICallback() {
            @Override
            public void onLoadMessages(List<Message> message) {
                //Assert.assertEquals(messages.get(0).getSubject(),message.get(0).getSubject());
                Assert.assertNotNull(message);
            }

            @Override
            public void onMarkRead(long id, int count) {

            }

            @Override
            public void onMessagesInserted(int count) {

            }

            @Override
            public void onMessageFound(Message message) {

            }
        });

    }

    @Test
    public void testReadStatusUpdate(){
        Context appContext = InstrumentationRegistry.getTargetContext();
        List<Message> messages =  new MessageGenerator().getMockMessage();
        MessagesRepository.getInstance(appContext).insertMessages(messages);
        MessagesRepository.getInstance(appContext).getMessages(new ICallback() {
            @Override
            public void onLoadMessages(List<Message> message) {
                MessagesRepository.getInstance(appContext).markRead(message.get(0).getId(), this);
            }

            @Override
            public void onMarkRead(long id, int count) {
               // Assert.assertEquals(1,count);
                MessagesRepository.getInstance(appContext).getMessage(id, this);
            }

            @Override
            public void onMessagesInserted(int count) {

            }

            @Override
            public void onMessageFound(Message message) {
                Assert.assertTrue(message.isRead());
            }
        });

    }

    @Test
    public void testInvalidMessage(){
        Context appContext = InstrumentationRegistry.getTargetContext();
        MessagesRepository.getInstance(appContext).getMessage(2167512876786L, new ICallback(){

            @Override
            public void onLoadMessages(List<Message> message) {

            }

            @Override
            public void onMarkRead(long id, int count) {

            }

            @Override
            public void onMessagesInserted(int count) {

            }

            @Override
            public void onMessageFound(Message message) {
                Assert.assertNull( message);
            }
        });
    }

}
