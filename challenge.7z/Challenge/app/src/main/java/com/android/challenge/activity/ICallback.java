package com.android.challenge.activity;

import com.android.challenge.provider.Message;

import java.util.List;

public interface ICallback {

    public void onLoadMessages(List<Message> message);

    public void onMarkRead(long id, int count);

    public void onMessagesInserted(int count);

    public void onMessageFound(Message message);
}
