package com.android.challenge.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.challenge.R;
import com.android.challenge.activity.swipe.SwipeActionAdapter;
import com.android.challenge.activity.swipe.SwipeDirection;
import com.android.challenge.provider.Message;
import com.android.challenge.provider.MessagesRepository;

import java.util.List;

public class MainActivity extends AppCompatActivity implements
        SwipeActionAdapter.SwipeActionListener, ICallback{
    protected SwipeActionAdapter mAdapter;
    private ListView messageList;
    private List<Message> mMessages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        messageList = (ListView)findViewById(R.id.messagelist);
        MessagesRepository.getInstance(this).getMessages(this);
    }

    @Override
    public boolean hasActions(int position, SwipeDirection direction){
        return true;
    }

    @Override
    public boolean shouldDismiss(int position, SwipeDirection direction){
        return false;//direction == SwipeDirection.DIRECTION_NORMAL_LEFT;
    }

    @Override
    public void onSwipe(int[] positionList, SwipeDirection[] directionList){
        for(int i=0;i<positionList.length;i++) {
            SwipeDirection direction = directionList[i];
            int position = positionList[i];
            switch (direction) {
                case DIRECTION_FAR_LEFT:
                case DIRECTION_FAR_RIGHT:
                    mMessages.get(position).setRead(true);
                    MessagesRepository.getInstance(this).markRead(mMessages.get(position).getId(),this);
                    break;
                case DIRECTION_NORMAL_LEFT:
                case DIRECTION_NORMAL_RIGHT:
                    break;

            }
            mAdapter.notifyDataSetChanged();
           //refreshAdapter(mMessages);
        }
    }

    @Override
    public void onLoadMessages(List<Message> messages) {
        if(messages != null){
            mMessages = messages;
           refreshAdapter(messages);
        }
    }
    @Override
    public void onMarkRead(long id, int count) {

    }

    @Override
    public void onMessagesInserted(int count) {

    }

    @Override
    public void onMessageFound(Message message) {

    }

    public void refreshAdapter(List<Message> messages){
        mAdapter = new SwipeActionAdapter(getAdapter(mMessages), messages);
        mAdapter.setSwipeActionListener(MainActivity.this)
                .setDimBackgrounds(true)
                .setListView(messageList);
        messageList.setAdapter(mAdapter);

        mAdapter.addBackground(SwipeDirection.DIRECTION_FAR_LEFT,R.layout.row_bg_left_far)
                .addBackground(SwipeDirection.DIRECTION_NORMAL_LEFT, R.layout.row_bg_left)
                .addBackground(SwipeDirection.DIRECTION_FAR_RIGHT, R.layout.row_bg_right_far)
                .addBackground(SwipeDirection.DIRECTION_NORMAL_RIGHT,R.layout.row_bg_right);
        mAdapter.notifyDataSetChanged();
    }



    public ArrayAdapter<String> getAdapter(List<Message> messages){
        String[] content = new String[messages.size()];
        int index = 0;
        for(Message msg : messages){
            content[index] = msg.getSubject();
            index++;
        }
        ArrayAdapter<String> stringAdapter = new ArrayAdapter<>(
                this,
                R.layout.row_bg,
                R.id.text,content);;
        return stringAdapter;
    }
}
