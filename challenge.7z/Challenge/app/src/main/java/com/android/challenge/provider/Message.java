package com.android.challenge.provider;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity
public class Message {

    public Message(String subject){
        this.subject = subject;
    }

    @PrimaryKey (autoGenerate = true)
    @NonNull
    @ColumnInfo (name = "id")
    private long id;

    @NonNull
    @ColumnInfo (name = "subject")
    private String subject;

    @NonNull
    @ColumnInfo (name = "read_status")
    private boolean read;


    @NonNull
    public long getId() {
        return id;
    }

    public void setId(@NonNull long id) {
        this.id = id;
    }

    @NonNull
    public String getSubject() {
        return subject;
    }

    public void setSubject(@NonNull String subject) {
        this.subject = subject;
    }

    @NonNull
    public boolean isRead() {
        return read;
    }

    public void setRead(@NonNull boolean read) {
        this.read = read;
    }


}
