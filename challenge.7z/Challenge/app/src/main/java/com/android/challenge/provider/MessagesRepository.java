package com.android.challenge.provider;

import android.content.Context;
import android.os.AsyncTask;

import com.android.challenge.activity.ICallback;

import java.util.List;

public class MessagesRepository {

    private List<Message> mMessages;

    private static AppDatabase mDb ;
    private static MessagesRepository mInstance;


    private MessagesRepository(){}

    public static MessagesRepository getInstance(Context context ){

        if(mInstance == null) {
            mInstance = new MessagesRepository();
            mDb = AppDatabase.getInstance(context);
        }
        return mInstance;
    }


    public void getMessages(ICallback callback) {
        new GetMessages(callback).execute();
    }

   public void markRead(long id, ICallback callback){
        new MarkRead(id, callback).execute();
   }

    public void insertMessages (List<Message> messages){
        new InsertMessages(messages).execute();
    }

    public void getMessage(long id, ICallback callback) {
        new GetMessage(id,callback).execute();
    }

    private class GetMessages extends AsyncTask<Void,Void,List<Message>>{

        private ICallback callback;

        public GetMessages(ICallback callback){
            this.callback = callback;
        }

        @Override
        protected List<Message> doInBackground(Void... voids) {

            List<Message> messages = mDb.messageDao().loadAllMessages();

            return messages;
        }

        @Override
        protected void onPostExecute(List<Message> messages) {
            super.onPostExecute(messages);
            mMessages = messages;
            callback.onLoadMessages(messages);
        }
    }



    private class MarkRead extends AsyncTask<Void,Void,Integer>{

        long id;
        ICallback callback;
        public MarkRead(long id, ICallback callback){
            this.id = id;
            this.callback = callback;
        }
        @Override
        protected Integer doInBackground(Void... voids) {
            int count = mDb.messageDao().updateReadStatus(id, true);
            return count;
        }

        @Override
        protected void onPostExecute(Integer integer) {
            super.onPostExecute(integer);
            callback.onMarkRead(id,integer.intValue());
        }
    }



    private class InsertMessages extends AsyncTask<Void,Void,Void>{

        List<Message> messages;
        public InsertMessages(List<Message> messages){
            this.messages = messages;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            mDb.messageDao().insertData(messages);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

    private class GetMessage extends AsyncTask<Void,Void,Message>{

        long id;
        ICallback callback;
        public GetMessage(long id, ICallback callback){
            this.id = id;
            this.callback = callback;
        }

        @Override
        protected Message doInBackground(Void... voids) {
            Message msg = mDb.messageDao().getMessage(id);
            return msg;
        }

        @Override
        protected void onPostExecute(Message message) {
            super.onPostExecute(message);
            callback.onMessageFound(message);
        }
    }


}
